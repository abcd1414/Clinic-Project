const express = require('express');
const http = require('http');
const bodyparser = require('body-parser');
const cors = require('cors');
const fs =require("fs");
const app = express();
app.use(cors());
app.use(bodyparser.json());
let port=3000;




app.get("/getData", async (req,res) => {
res.json({
"statuscode":200,
"statusMessage":"SUCCESS"
})
});

app.listen(port, (req,res) =>{
console.log ('server connected on port:' +port);

})